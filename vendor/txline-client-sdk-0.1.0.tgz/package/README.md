# @txline/client-sdk

Typed REST + resumable-SSE client for the TxLINE data platform (the `txline-explorer` repo).
**Standalone** — no workspace dependency, installable from any separate project.

## Install

No registry is set up yet, so install from a built tarball:

```bash
# inside txline-explorer/packages/client-sdk
pnpm run build && npm pack
# in YOUR project
npm install /path/to/txline-explorer/packages/client-sdk/txline-client-sdk-0.1.0.tgz
```

## Use

```ts
import { TxlinePlatformClient } from "@txline/client-sdk";

const client = new TxlinePlatformClient({
  baseUrl: "http://localhost:3001", // or your deployed platform URL
  apiKey: process.env.TXLINE_API_KEY, // not required against localhost in dev
});

const corpus = await client.corpus();
const fixture = await client.fixture(18241006);

const stop = client.stream("odds", (evt) => {
  console.log(evt.id, evt.data); // resumes automatically on any disconnect — never loses an event
});
// later: stop();
```

Every REST method and the full resumable-stream contract are documented in the platform repo's
`docs/CONSUMER-GUIDE.md` and `docs/BUILDING-NEW-APPS.md` — read those before building against
this. Types (`FixtureDetail`, `OddsSeriesResponse`, `StreamEvent`, …) are a generated snapshot of
the platform's own contract (`packages/shared`), refreshed on every build — they can't drift.
