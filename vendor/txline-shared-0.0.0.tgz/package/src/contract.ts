/**
 * TxLINE platform consumer contract (platform plan Phase C-3). The single compile-time source of
 * truth for the request/response/event shapes that cross the versioned `/v1` HTTP surface. The
 * Fastify API produces them, the agent CLI + web console consume them, and any backend service that
 * imports `@txline/shared` types its integration against exactly these interfaces.
 *
 * These are the WIRE shapes (what a consumer receives over HTTP/SSE), derived from the real route
 * handlers in apps/api. The richer domain/decoder types (ScoreUpdate, OddsPayload, …) live in
 * ./types.ts; this file assembles them into response envelopes and stream events.
 */
import type {
  LineupTeam,
  OddsPayload,
  ScoreUpdate,
  SoccerFixturePlayerStats,
  TimelineEvent,
} from "./types.js";

// ── Fixtures ────────────────────────────────────────────────────────────────

export type FixtureStatus = "played" | "live" | "upcoming";

/** One row in the fixtures list / the `fixture` block of a detail response. */
export interface FixtureRow {
  fixtureId: number;
  startTime: number | null;
  competition: string | null;
  competitionId: number | null;
  fixtureGroupId: number | null;
  participant1Id: number | null;
  participant1: string | null;
  participant2Id: number | null;
  participant2: string | null;
  participant1IsHome: boolean | null;
  statusId: number | null;
  statusLabel: string;
  finalScore: [number, number] | null;
  isFinal: boolean;
  status: FixtureStatus;
  source: string | null;
  scoreCount: number;
  oddsTickCount: number;
}

export interface FixturesListResponse {
  total: number;
  fixtures: FixtureRow[];
}

// ── Corpus / ingestion summary ────────────────────────────────────────────────

export interface CorpusCounts {
  fixtures: number;
  scoreUpdates: number;
  oddsTicks: number;
  oddsSeries: number;
}

export interface CorpusResponse {
  corpus: CorpusCounts;
  ingestion: { fixturesTracked: number; finalized: number };
  apiBase: string;
  serviceLevelId: number;
}

// ── Timeline / fixture detail ────────────────────────────────────────────────

export type PossessionLevel = "safe" | "neutral" | "attack" | "danger" | "high";

/**
 * A folded phase of a fixture (one status span). Beyond the transition point (`ts`/`seq`) it carries
 * the wall-clock BOUNDS and the match-minute anchor — the canonical wall→(match-minute, phase) map,
 * computed server-side from the scores clock so no consumer re-derives it. `matchMinuteStart` is the
 * match-minute at `wallStart` (H1→0, H2→~45, ET1→~90, FET→120…) and is MONOTONIC non-decreasing
 * across a fixture's phases (safe to build a match-clock axis from); it is `null` ONLY for the
 * penalty phase (no running clock — kicks locate by phase+index). `code` is the status code
 * (H1/HT/H2/FT/WET/ET1/HTET/ET2/FET/WPE/PE/FPE/…).
 */
export interface Phase {
  status: number;
  code: string;
  label: string;
  ts: number;
  seq: number;
  /** Wall-clock ms at which this phase began (== `ts`). */
  wallStart: number;
  /** Wall-clock ms at which the next phase began, or the fixture's last update ts for the final phase. */
  wallEnd: number | null;
  /** Match-minute at `wallStart`; monotonic non-decreasing across phases; null only for the penalty phase. */
  matchMinuteStart: number | null;
}

/** One possession-pressure sample (safe/neutral/attack/danger/high) from the score feed. */
export interface PossessionSample {
  ts: number;
  seq: number;
  minute?: number;
  clockSeconds?: number;
  participant?: number;
  level: PossessionLevel;
  action: string;
  possessionType?: string;
}

/**
 * The penalty-shootout result, when a fixture went to penalties. `p1`/`p2` are the penalties SCORED
 * by each participant, derived by counting confirmed `penalty_outcome` kicks (the authoritative
 * source — the on-wire 6xxx running tally can stop before the deciding kick). `finalScore` on the
 * timeline stays the ET/regulation goals score and is NEVER overwritten by the shootout.
 */
export interface ShootoutResult {
  decidedBy: "penalties";
  p1: number;
  p2: number;
  winner: 1 | 2 | null;
}

/** A fixture's reconstructed match timeline (events, phases, possession, action histogram). */
export interface MatchTimeline {
  fixtureId: number;
  competitionId: number;
  participant1Id: number;
  participant2Id: number;
  participant1IsHome: boolean;
  startTime: number;
  updates: number;
  phases: Phase[];
  events: TimelineEvent[];
  possession: PossessionSample[];
  actionCounts: Record<string, number>;
  finalScore: { p1: number; p2: number };
  /** Present only when the fixture was decided on penalties. Separate from finalScore (goals). */
  shootout?: ShootoutResult;
  isFinal: boolean;
}

/** A quote-suspension moment (`suspend` action) — rendered as an honest break, never interpolated. */
export interface SuspensionMarker {
  ts: number;
  seq: number;
}

export interface FixtureDetail {
  fixture: FixtureRow;
  timeline: MatchTimeline;
  /** kickoff anchor (first in-play status transition ts) — maps odds epoch-minutes → match time. */
  kickoffTs: number | null;
  suspensions: SuspensionMarker[];
  lineups?: LineupTeam[];
  playerStats?: SoccerFixturePlayerStats;
}

// ── Point-in-time state ──────────────────────────────────────────────────────

export interface DecodedStat {
  key: number;
  participant: 1 | 2;
  metric: string;
  period: string;
  value: number;
}

export interface StateAtSeq {
  fixtureId: number;
  requestedSeq: number;
  seq: number;
  ts: number;
  action: string | null;
  statusId: number | null;
  statusLabel: string;
  confirmed: boolean | null;
  clock?: { running: boolean; seconds: number };
  possession?: number;
  possessionType?: string;
  score?: { participant1: number; participant2: number };
  stats: DecodedStat[];
  predictors?: {
    parti1?: Record<string, boolean>;
    parti2?: Record<string, boolean>;
    neutral?: Record<string, boolean>;
  };
  raw: ScoreUpdate;
}

// ── Odds ─────────────────────────────────────────────────────────────────────

/**
 * Match phase a market tuple belongs to, derived from its `market_period`. Extra-time and penalty
 * odds live under DEDICATED tuples ('et', 'et,half=1', 'penalties') — a base regulation market ('')
 * legitimately ends at full-time. This tag lets a consumer render distinct phase SEGMENTS (never
 * one merged line: full-time result ≠ extra-time result). See the `?phases=all` odds param.
 */
export type OddsPhase = "regulation" | "regulation-1h" | "extra-time" | "extra-time-1h" | "penalties";

export interface OddsSeriesRow {
  superOddsType: string;
  marketPeriod: string;
  marketParameters: string;
  /** Derived from marketPeriod — the match phase this row belongs to. */
  phase: OddsPhase;
  /** Match-minute at this bucket, from the fixture's phase timeline; null in penalties/pre-kickoff. */
  matchMinute: number | null;
  priceName: string;
  minuteBucket: number;
  priceOpen: number | null;
  priceHigh: number | null;
  priceLow: number | null;
  priceClose: number | null;
  pctOpen: number | null;
  pctHigh: number | null;
  pctLow: number | null;
  pctClose: number | null;
  tickCount: number;
}

/** A raw odds tick with its server-derived match phase + match-minute attached. */
export type OddsRawTick = OddsPayload & { phase: OddsPhase; matchMinute: number | null };

export interface MarketFilterEcho {
  superOddsType?: string;
  marketPeriod?: string;
  marketParameters?: string;
}

export interface OddsSeriesResponse {
  fixtureId: number;
  kind: "series";
  filter: MarketFilterEcho;
  asOf: number | null;
  /** True when `?phases=all` merged every phase-tuple of the requested market (period unpinned). */
  phasesAll: boolean;
  series: OddsSeriesRow[];
}

export interface OddsRawResponse {
  fixtureId: number;
  kind: "raw";
  filter: MarketFilterEcho;
  asOf: number | null;
  phasesAll: boolean;
  ticks: OddsRawTick[];
}

export interface MarketTupleRow {
  superOddsType: string;
  marketPeriod: string;
  marketParameters: string;
  tickCount: number;
  firstTs: number;
  lastTs: number;
  fixtureCount?: number;
  priceNames?: string[];
}

export interface MarketsResponse {
  fixtureId: number | null;
  markets: MarketTupleRow[];
}

// ── Coverage census ──────────────────────────────────────────────────────────

export interface CoverageEntry {
  key: string;
  count: number;
  firstTs: number | null;
  lastTs: number | null;
  firstSeen: string | null;
  lastSeen: string | null;
  extra?: Record<string, unknown>;
}

export interface CoverageCensus {
  built: boolean;
  dimensions: {
    action: CoverageEntry[];
    status: CoverageEntry[];
    statKey: CoverageEntry[];
    dataKey: CoverageEntry[];
    market: CoverageEntry[];
  };
  reliability: Record<string, number>;
  totals: { actions: number; statuses: number; statKeys: number; dataKeys: number; markets: number };
}

// ── Worker health ────────────────────────────────────────────────────────────

export interface WorkerStreamHealth {
  conn: "open" | "connecting" | "closed" | string;
  lagMs: number | null;
  reconnects: number;
  lastRecordAt: number | null;
}

export interface WorkerReport {
  running: boolean;
  pid?: number;
  startedAt?: number;
  uptimeMs?: number;
  heartbeatAgeMs?: number;
  streams?: Record<string, WorkerStreamHealth>;
  directory?: { lastRefreshAt: number | null; fixtures: number };
  gapCheck?: { lastRunAt: number | null; checked: number };
  note?: string;
  [k: string]: unknown;
}

// ── On-chain validation (spec §6) ──────────────────────────────────────────────

/** Result of the read-only on-chain verification (spec §6, A4.1). */
export interface OnChainVerification {
  verified: boolean;
  fixtureId: number;
  namespacedFixtureId: string;
  proofTs: number;
  epochDay: number;
  fiveMinSlot: number;
  programId: string;
  pda: string;
  pdaExists: boolean;
  pdaEpochDay: number | null;
  pdaEpochDayMatches: boolean;
  subTreeVerified: boolean;
  mainTreeVerified: boolean;
  computedRootHex: string;
  onChainRootHex: string | null;
  failureMode: string | null;
}

/** Shape of the scores stat-validation Merkle proof (spec §6). Open — extra keys pass through. */
export interface ScoreProof {
  ts?: number;
  statsToProve?: { key: number; value: number; period?: number | string }[];
  eventStatRoot?: string;
  summary?: Record<string, unknown>;
  statProofs?: unknown;
  subTreeProof?: { hash?: string; isRightSibling?: boolean }[];
  mainTreeProof?: { hash?: string; isRightSibling?: boolean }[];
  [k: string]: unknown;
}

export interface ScoresValidationResponse {
  fixtureId: number;
  seq: number;
  statKeys: number[];
  onChain: OnChainVerification | { error: string } | null;
  proof: ScoreProof;
}

export interface FixtureValidationResponse {
  fixtureId: number;
  namespacedFixtureId: string;
  proof: Record<string, unknown>;
}

export interface OddsValidationResponse {
  messageId: string;
  ts: number;
  proof: Record<string, unknown>;
}

// ── Errors ───────────────────────────────────────────────────────────────────

/** Uniform error body returned by every `/v1` route on 4xx/5xx. */
export interface ApiErrorBody {
  error: string;
  /** machine-readable code, present on auth + rate-limit failures. */
  code?: string;
}

// ── SSE stream contract (platform plan Phase C-5) ─────────────────────────────

/**
 * Every `/v1/stream/*` event carries a monotonic `id` (SSE `Last-Event-ID`). The id is the SQLite
 * rowid of the underlying row — score_updates.rowid for scores, odds_ticks.rowid for odds — so it
 * is a durable, gap-free cursor into the corpus. The filtered `/v1/stream/fixtures/:id` stream
 * multiplexes both kinds and uses a COMPOSITE id `"<scoresRowid>.<oddsRowid>"`.
 *
 * On reconnect the consumer sends `Last-Event-ID` (or `?since=`); the server replays every row
 * after that cursor straight from SQLite, then continues live — no event is ever lost across a
 * disconnect.
 */
export type StreamEventName = "open" | "score" | "odds" | "keep-alive";

/** The `event: open` payload sent once when a stream is (re)established. */
export interface StreamOpenData {
  stream: "scores" | "odds" | "fixture";
  /** the cursor the stream is resuming FROM (0 or the requested since). */
  since: string;
  /** the cursor at the head of the log right now (what a fresh live-tail would start at). */
  head: string;
  fixtureId?: number;
  replaying: boolean;
}

/** A single decoded stream event as delivered to a consumer (id = SSE Last-Event-ID). */
export interface StreamEvent<T = ScoreUpdate | OddsPayload> {
  id: string;
  event: "score" | "odds";
  data: T;
}

export type ScoreStreamEvent = StreamEvent<ScoreUpdate> & { event: "score" };
export type OddsStreamEvent = StreamEvent<OddsPayload> & { event: "odds" };
