/**
 * Full TxLINE soccer data model — the source of truth for both apps/api and apps/web.
 *
 * The live wire is **PascalCase** (FixtureId, Seq, StatusId, Data, Score…) even though the
 * OpenAPI spec documents camelCase — verified against real fixtures (see
 * docs/TXLINE-FOOTBALL-REFERENCE.md and docs/txline-api-reference/README.md §0). These types
 * mirror reality. Every envelope also keeps its legacy pre-2026-06-04 aliases so archived
 * payloads still decode; the decoders normalize via `??`.
 *
 * Open-set principle (spec §5): action names, Data sub-keys, and odds market tuples are OPEN
 * SETS. Raw JSON is always persisted alongside the decoded view so unknown values are never
 * lost — these interfaces are a convenience over the raw, never a filter on it.
 */

/** A fixture (match) directory entry. */
export interface Fixture {
  Ts: number;
  StartTime: number;
  Competition: string;
  CompetitionId: number;
  FixtureGroupId: number;
  Participant1Id: number;
  Participant1: string;
  Participant2Id: number;
  Participant2: string;
  FixtureId: number;
  Participant1IsHome: boolean;
  GameState?: string;
}

export interface Clock {
  Running: boolean;
  Seconds: number;
}

/** Per-period leaf counters. All optional (absent ⇒ 0). */
export interface SoccerScore {
  Goals?: number;
  YellowCards?: number;
  RedCards?: number;
  Corners?: number;
}

/** Period-bucketed score for one participant (full/H1/HT/H2/ET1/ET2/PE/ETTotal). */
export interface SoccerTotalScore {
  H1?: SoccerScore;
  HT?: SoccerScore;
  H2?: SoccerScore;
  ET1?: SoccerScore;
  ET2?: SoccerScore;
  PE?: SoccerScore;
  ETTotal?: SoccerScore;
  Total?: SoccerScore;
}

export interface SoccerFixtureScore {
  Participant1?: SoccerTotalScore;
  Participant2?: SoccerTotalScore;
}

/**
 * Event-specific payload (`Data`, legacy `DataSoccer`). Superset of all observed sub-fields.
 * Match-context extras from the OpenAPI spec (§5) included; casing decoded tolerantly.
 */
export interface SoccerData {
  StatusId?: number;
  GoalType?: string;
  Type?: string;
  Outcome?: string;
  FreeKickType?: string;
  ThrowInType?: string;
  Color?: string;
  Minutes?: number;
  PlayerId?: number;
  PlayerInId?: number;
  PlayerOutId?: number;
  Participant?: number;
  Goal?: boolean;
  Corner?: boolean;
  Penalty?: boolean;
  /** substitution linkage (v1.1+) */
  FollowsAction?: number;
  /** comment body (e.g. "Water-drinking break") */
  Text?: string;
  /** weather / pitch-condition strings */
  Conditions?: string[];
  /** Home | Away | Neutral */
  VenueType?: string;
  /** action_amend envelope: amended verb + field-level diff + who it applies to */
  Action?: string;
  New?: Record<string, unknown>;
  Previous?: Record<string, unknown>;
  [key: string]: unknown;
}

export type PossessionTypeName =
  | "SafePossession"
  | "AttackPossession"
  | "DangerPossession"
  | "HighDangerPossession";

/** Parti1State / Parti2State — per-team imminent-event predictor ({Goal,Penalty,Corner}). */
export interface PossibleState {
  PossibleEvent?: Record<string, boolean>;
}

/** Neutral imminent-event predictor ({RedCard,YellowCard,VAR}); wire key top-level `PossibleEvent`. */
export type PossibleNeutralEvent = Record<string, boolean>;

/** Per-player aggregate performance (SoccerPlayerStats), keyed by normativeId (new mid-tournament). */
export interface SoccerPlayerStats {
  goals?: number;
  shots?: number;
  ownGoals?: number;
  penaltyAttempts?: number;
  penaltyGoals?: number;
  yellowCards?: number;
  redCards?: number;
}

export interface SoccerFixturePlayerStats {
  Participant1?: Record<string, SoccerPlayerStats>;
  Participant2?: Record<string, SoccerPlayerStats>;
}

/** Lineups[] — roster/position metadata (no performance numbers). */
export interface LineupPlayer {
  fixturePlayerId?: number;
  statusId?: number;
  positionId?: number;
  unitId?: number;
  rosterNumber?: string;
  starter?: boolean;
  starred?: boolean;
  player?: {
    id?: string;
    normativeId?: number;
    country?: string;
    team?: number;
    dateOfBirth?: string;
    gender?: string;
    preferredName?: string;
  };
}

export interface LineupTeam {
  id?: string;
  normativeId?: number;
  preferredName?: string;
  gender?: string;
  updateDateMillis?: number;
  lineups?: LineupPlayer[];
}

/** One scores update envelope. `Action` carries the event verb (open set). */
export interface ScoreUpdate {
  FixtureId: number;
  GameState: string;
  StartTime: number;
  IsTeam: boolean;
  FixtureGroupId: number;
  CompetitionId: number;
  CountryId: number;
  SportId: number;
  Participant1IsHome: boolean;
  Participant1Id: number;
  Participant2Id: number;
  Action: string;
  Id: number;
  Ts: number;
  ConnectionId: number;
  Seq: number;
  Type?: string;
  Clock?: Clock;
  Confirmed?: boolean;
  Participant?: number;
  CoverageType?: string;
  CoverageSecondaryData?: boolean;
  Stats?: Record<string, number>;
  // canonical (2026-06-04+)
  StatusId?: number;
  Data?: SoccerData;
  Score?: SoccerFixtureScore;
  Possession?: number;
  PossessionType?: PossessionTypeName | string;
  Parti1State?: PossibleState;
  Parti2State?: PossibleState;
  /** neutral imminent-event predictor (top-level wire key `PossibleEvent`) */
  PossibleEvent?: PossibleNeutralEvent;
  Kickoff?: { Team?: number } & Record<string, unknown>;
  Lineups?: LineupTeam[];
  /** per-player stats (top-level wire key `PlayerStats`) */
  PlayerStats?: SoccerFixturePlayerStats;
  // legacy aliases (pre-2026-06-04)
  StatusSoccerId?: number;
  DataSoccer?: SoccerData;
  ScoreSoccer?: SoccerFixtureScore;
  /** anything the open set adds that we haven't named */
  [key: string]: unknown;
}

/** Odds update / StablePrice payload. */
export interface OddsPayload {
  FixtureId: number;
  MessageId: string;
  Ts: number;
  Bookmaker: string;
  BookmakerId: number;
  SuperOddsType: string;
  GameState?: string;
  InRunning: boolean;
  MarketParameters?: string | null;
  MarketPeriod?: string | null;
  PriceNames?: string[];
  /** Prices[i]/1000 = decimal odds */
  Prices?: number[];
  /** de-margined fair probability %, 3dp, or "NA" for split/quarter handicaps */
  Pct?: string[];
  [key: string]: unknown;
}

/** A market is identified by this tuple (never a hardcoded catalog). */
export interface MarketTuple {
  superOddsType: string;
  marketPeriod: string;
  marketParameters: string;
}

/** Decoded stat key: e.g. 1001 → {participant:1, metric:"Goals", period:"H1"}. */
export interface DecodedStatKey {
  participant: 1 | 2;
  metric: string;
  period: string;
  baseKey: number;
  periodOffset: number;
}

/** A folded, deduplicated timeline event. */
export interface TimelineEvent {
  ts: number;
  seq: number;
  action: string;
  participant?: number;
  playerId?: number;
  playerInId?: number;
  playerOutId?: number;
  minute?: number;
  score?: [number, number];
  detail?: string;
  confirmed?: boolean;
  /** 1-based order of this penalty within a shootout (penalty_outcome events only; no match-minute). */
  shootoutKickIndex?: number;
}
