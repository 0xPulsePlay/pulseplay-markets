# @txline/verify

Client-side, **trust-minimized** verification of TxLINE's Solana-anchored Merkle proofs.

TxLINE publishes football scores/odds and anchors a Merkle root of every update on Solana. This
package lets *you* reconstruct that Merkle chain yourself and compare it against the root the oracle
program committed on-chain — so you verify the math instead of trusting a server's "✓ verified" badge.

- **Read-only & free.** Only `getAccountInfo` reads + pure hashing. It never builds, signs, or sends
  a transaction, never touches a keypair, and spends zero SOL.
- **Isomorphic.** Runs in the browser and in Node. sha256 comes from [`@noble/hashes`](https://github.com/paulmillr/noble-hashes)
  (tiny, audited) — no `node:crypto`. The only other dependency is `@solana/web3.js`.
- **Standalone.** No workspace dependency; installable from any project.

## Install

No registry is set up yet, so install from a built tarball:

```bash
# inside txline-explorer/packages/verify
pnpm run build && npm pack
# in YOUR project
npm install /path/to/txline-explorer/packages/verify/txline-verify-0.1.0.tgz
```

> Browser note: like `@solana/web3.js` itself, this package uses `Buffer`. Modern bundlers (Vite,
> webpack 5, Next.js) inject a `Buffer` polyfill automatically; no code change is needed.

## Use — Node

```ts
import { verifyScoresStatProofOnChain, describeStatKey } from "@txline/verify";

// `proof` is a scores stat-validation response from the TxLINE platform.
const res = await verifyScoresStatProofOnChain("https://api.mainnet-beta.solana.com", proof);

console.log(res.verified);          // true only if BOTH Merkle levels + the PDA epochDay all check out
console.log(res.computedRootHex);   // the root we reconstructed client-side
console.log(res.onChainRootHex);    // the root the oracle anchored on Solana — these must be equal
console.log(res.failureMode);       // null when verified, else a precise reason

for (const s of res.statsToProve) {
  console.log(describeStatKey(s.key).label, "=", s.value); // e.g. "Goals — Home (full match) = 2"
}
```

## Use — Browser

A `Connection` works in the browser and already satisfies the reader interface — pass it as the
third argument so no server-side RPC is involved:

```ts
import { Connection } from "@solana/web3.js";
import { verifyScoresStatProofOnChain } from "@txline/verify";

const conn = new Connection("https://api.mainnet-beta.solana.com", "confirmed");
const res = await verifyScoresStatProofOnChain("", proof, conn);
```

Or inject your own read function over any RPC / indexer — anything shaped like `getAccountInfo`:

```ts
import { verifyScoresStatProofOnChain, type AccountReader } from "@txline/verify";

const reader: AccountReader = {
  async getAccountInfo(pubkey) {
    const info = await myRpc.getAccountInfo(pubkey.toBase58()); // your gateway
    return info ? { data: info.data } : null;                   // data: Uint8Array | Buffer
  },
};
const res = await verifyScoresStatProofOnChain("", proof, reader);
```

## Devnet

Every function defaults to mainnet but accepts a network (or an explicit program id):

```ts
await verifyScoresStatProofOnChain("https://api.devnet.solana.com", proof, conn, { network: "devnet" });

dailyScoresRootsPda(epochDay, { network: "devnet" });
resolveProgramId({ programId: "6pW64gN1s2uqjHkn1unFeEjAwJkPGHoppGvS715wyP2J" });
```

## Fixtures & odds

Fixture and odds proofs verify end-to-end the same way — reconstruct the leaf, walk the sub-tree to
the summary root, then walk the summary leaf to the root the oracle anchored on-chain:

```ts
import { verifyFixtureProofOnChain, verifyOddsProofOnChain } from "@txline/verify";

const fx = await verifyFixtureProofOnChain("https://api.mainnet-beta.solana.com", fixtureProof);
const od = await verifyOddsProofOnChain("https://api.mainnet-beta.solana.com", oddsProof);
console.log(fx.verified, od.verified);   // true only if BOTH Merkle levels + the PDA epochDay check out
console.log(fx.failureMode, od.failureMode); // precise reason on failure
```

Both accept the same optional `reader` and `{ network }` arguments as the scores verifier.

## Program-enforced scores verification (the whole stat tree)

The scores **stat-leaf** tier is a bespoke indexed/sparse accumulator (not a plain sha256 Merkle
path), so the client can only reconstruct it for present stats (`statLeaf` — membership; value=0 stats
are proven by a non-membership sentinel path we don't reconstruct). To verify *everything* — including
the accumulator and value=0 non-membership — let the on-chain program do it, read-only:

```ts
import { verifyStatProofViaProgram } from "@txline/verify";

const res = await verifyStatProofViaProgram(
  "https://api.mainnet-beta.solana.com",
  scoresProof,
  { threshold: 0, comparison: "greaterThan" }, // the predicate the program evaluates
);
console.log(res.verified);        // proof is cryptographically valid (ALL tiers, program-attested)
console.log(res.predicateResult); // the boolean the program computed for your predicate
console.log(res.logs);            // program logs (evidence)
```

This builds the oracle's own `validate_stat` instruction and runs it through `simulateTransaction`
with `sigVerify: false` + `replaceRecentBlockhash: true` — **nothing is signed, submitted, or spent**
(the read-only equivalent of the program's `.view()`). A clean simulation is the program itself
attesting every tier holds; a tampered proof fails closed with the program's own error. `verified`
means the proof is authentic — it does **not** revert on a false predicate, so check `predicateResult`
separately for settlement. `buildValidateStatInstruction(proof, predicate)` is exported standalone as
the CPI/instruction-builder core.

### Multi-leg (V3) — settle a whole market in one call

`verifyStatProofV3ViaProgram(rpcUrl, v3Proof, opts?)` simulates `validate_stat_v3`, which verifies
**every leg** of a `/v3` proof (all stats batched behind one shared multiproof) in a single read-only
call — including value=0 **non-membership** legs, so **absence markets** ("no red card", "no goal in
H1") resolve the same way. `buildValidateStatV3Instruction(v3Proof, opts?)` is the standalone CPI core.
Predicates are the documented `Strategy` (`buildStrategyTrailer([...])`) — `single{index,threshold,comparison}`
and `binary{indexA,indexB,op,threshold,comparison}` (goal-difference / total markets), with indexes as
positions in `statsToProve`. The oracle requires the strategy to **cover every proven stat**, so the
default is a full-coverage `verifyAllStrategy` (one `EqualTo`-its-value term per leg); arbitrary
`GreaterThan`/`LessThan` work once all legs are covered. The full V1/V2/V3 Borsh layouts, the `Strategy`
struct, and the absence-proof structure live in `docs/oracle-wire-formats.md`.

## Verification coverage

Every asserted fact is bound cryptographically to the on-chain root — nothing is trusted from the
server. What each verifier proves today:

| Proof | Sub-tree (event leaf → summary root) | Main tree (summary leaf → on-chain PDA root) |
|---|---|---|
| **Fixtures** (`ten_daily_fixtures_roots`) | ✅ `sha256(borsh(snapshot))` | ✅ `sha256(0x01 ‖ borsh(fixtureBatchSummary))` |
| **Odds** (`daily_batch_roots`) | ✅ `sha256(borsh(odds))` | ✅ `sha256(0x01 ‖ borsh(oddsBatchSummary))` |
| **Scores** (`daily_scores_roots`) — client | ✅ membership stats (folded into `verified`); value=0 = non-membership¹ | ✅ `sha256(0x01 ‖ borsh(scoresBatchSummary))` |
| **Scores** — program (simulation) | ✅ full accumulator incl. value=0 non-membership | ✅ program-attested |

¹ `verifyScoresStatProofOnChain` reconstructs each **present (nonzero)** stat's leaf up to
`eventStatRoot` and folds the result into `verified` (`statLeavesVerified` + a per-stat `statLeaves`
breakdown; a tampered nonzero stat flips `verified` to false with `failureMode: "InvalidStatProof"`).
**value=0** stats are non-membership sentinels (not a sha256 walk) — exempt client-side (tiers 2+3
still bind the event); verify those with `verifyStatProofViaProgram`. Fixture/odds proofs are fully
end-to-end client-side.

## What's in the box

| Export | What it does |
|---|---|
| `verifyClaim(rpcUrl, proof, opts?)` / `pickValidator(proof, opts?)` | **Start here** — auto-routes a proof to V1/V3, returns the verdict + `{chosen, reason, estimatedCU}` |
| `verifyScoresStatProofOnChain(rpcUrl, proof, reader?, opt?)` | Scores stat proof, client tiers 2+3 → `OnChainScoreVerification` |
| `verifyStatProofViaProgram(rpcUrl, proof, predicate, opts?)` | Program-attested scores verification via simulation → `ProgramVerification` |
| `verifyStatProofV3ViaProgram(rpcUrl, v3Proof, opts?)` | Multi-leg V3 verification (all legs + absence markets) in one simulated call |
| `buildValidateStatInstruction` / `buildValidateStatV3Instruction` | Build the on-chain `validate_stat` / `_v3` instruction (CPI/settlement core) |
| `verifyFixtureProofOnChain(rpcUrl, proof, reader?, opt?)` | Fixture proof → `FixtureProofVerification` |
| `verifyOddsProofOnChain(rpcUrl, proof, reader?, opt?)` | Odds proof → `OddsProofVerification` |
| `statLeaf(stat)` | Client-side scores stat leaf `sha256(borsh(scoreStat))` (membership) |
| `fixtureLeaf` / `fixtureBatchSummaryLeaf` / `oddsLeaf` / `oddsBatchSummaryLeaf` | Compute individual Borsh Merkle leaves |
| `walkProof(start, proof)` | Walk a Merkle sibling path (`sha256(left‖right)` per `isRightSibling`) |
| `epochDayFromTs(ts)` / `fiveMinSlot(ts, ed)` / `fixtureRootIndex(ts, ed)` / `alignedEpochDay(ed)` | Time → PDA coordinates (derive from the **proof's** ts, never `Date.now()`) |
| `dailyScoresRootsPda` / `dailyBatchRootsPda` / `tenDailyFixturesRootsPda` | Derive the three roots PDAs |
| `describeStatKey(key)` | Decode an integer stat key → `{ base, side, period, label }` |
| `TXLINE_PROGRAM_IDS` / `resolveProgramId(opt?)` | mainnet/devnet program ids + selection helper |

The Merkle scheme, PDA layouts, and encodings are documented in the platform repo's
`docs/txline-api-reference/README.md` (§5 Stats, §6 On-chain validation) and the archived program IDL.
